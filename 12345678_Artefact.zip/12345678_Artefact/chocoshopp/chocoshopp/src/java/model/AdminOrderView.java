package model;

import java.io.Serializable;
import java.sql.Timestamp;

public class AdminOrderView implements Serializable {

    private int orderId;
    private String userEmail;
    private Timestamp orderDate;
    private double total;

    public AdminOrderView() {
    }

    public AdminOrderView(int orderId, String userEmail, Timestamp orderDate, double total) {
        this.orderId = orderId;
        this.userEmail = userEmail;
        this.orderDate = orderDate;
        this.total = total;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public Timestamp getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Timestamp orderDate) {
        this.orderDate = orderDate;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
}