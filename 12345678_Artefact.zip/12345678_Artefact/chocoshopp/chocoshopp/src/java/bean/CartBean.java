package bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import model.CartItem;

@Named("cartBean")
@SessionScoped
public class CartBean implements Serializable {

    private List<CartItem> cartItems = new ArrayList<>();

    public List<CartItem> getCartItems() {
        return cartItems;
    }

    public void setCartItems(List<CartItem> cartItems) {
        this.cartItems = cartItems;
    }

    public String addItem(String productName, double price) {
        for (CartItem item : cartItems) {
            if (item.getProductName().equals(productName)) {
                item.setQuantity(item.getQuantity() + 1);
                return "cart?faces-redirect=true";
            }
        }

        cartItems.add(new CartItem(productName, price, 1));
        return "cart?faces-redirect=true";
    }

    public void updateQuantity(CartItem item) {
        if (item.getQuantity() < 1) {
            item.setQuantity(1);
        }
    }

    public void removeItem(CartItem item) {
        cartItems.remove(item);
    }

    public void clearCart() {
        cartItems.clear();
    }

    public double getTotalPrice() {
        double total = 0.0;
        for (CartItem item : cartItems) {
            total += item.getSubtotal();
        }
        return total;
    }
}