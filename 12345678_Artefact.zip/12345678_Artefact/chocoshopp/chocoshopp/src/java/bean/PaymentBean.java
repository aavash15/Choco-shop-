package bean;

import java.io.Serializable;
import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import dao.ProductDAO;
import dao.OrderDAO;
import model.CartItem;

@Named("paymentBean")
@SessionScoped
public class PaymentBean implements Serializable {

    private String cardholderName;
    private String cardNumber;
    private String expiryDate;
    private String cvv;
    private String billingAddress;
    private String message;

    @Inject
    private CartBean cartBean;

    @Inject
    private LoginBean loginBean;

    public String getCardholderName() {
        return cardholderName;
    }

    public void setCardholderName(String cardholderName) {
        this.cardholderName = cardholderName;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public String getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(String billingAddress) {
        this.billingAddress = billingAddress;
    }

    public String getMessage() {
        return message;
    }

    public String processPayment() {

        if (cartBean == null || cartBean.getCartItems() == null || cartBean.getCartItems().isEmpty()) {
            message = "Your cart is empty.";
            return null;
        }

        if (loginBean == null || !loginBean.isLoggedIn()) {
            message = "Please login before checkout.";
            return "login?faces-redirect=true";
        }

        if (cardholderName == null || cardholderName.trim().isEmpty()
                || cardNumber == null || cardNumber.trim().isEmpty()
                || expiryDate == null || expiryDate.trim().isEmpty()
                || cvv == null || cvv.trim().isEmpty()
                || billingAddress == null || billingAddress.trim().isEmpty()) {
            message = "Missing fields. Please complete all checkout fields.";
            return null;
        }

        String cleanedCardNumber = cardNumber.replaceAll("\\s+", "");

        if (!cleanedCardNumber.matches("\\d{16}")) {
            message = "Card number must be exactly 16 digits.";
            return null;
        }

        if (!cvv.matches("\\d{3}")) {
            message = "CVV must be exactly 3 digits.";
            return null;
        }

        if (!expiryDate.matches("(0[1-9]|1[0-2])/\\d{2}")) {
            message = "Expiry date must be in MM/YY format.";
            return null;
        }

        ProductDAO productDAO = new ProductDAO();
        OrderDAO orderDAO = new OrderDAO();

        for (CartItem item : cartBean.getCartItems()) {
            productDAO.reduceStock(item.getProductName(), item.getQuantity());
        }

        orderDAO.addOrder(loginBean.getUserId(), cartBean.getTotalPrice());

        cartBean.clearCart();

        cardholderName = null;
        cardNumber = null;
        expiryDate = null;
        cvv = null;
        billingAddress = null;
        message = null;

        return "paymentSuccess?faces-redirect=true";
    }
}