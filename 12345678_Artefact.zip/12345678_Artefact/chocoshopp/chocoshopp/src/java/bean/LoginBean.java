package bean;

import dao.UserDAO;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import model.User;

@Named("loginBean")
@SessionScoped
public class LoginBean implements Serializable {

    private String email;
    private String password;
    private String name;
    private int userId;
    private boolean loggedIn = false;
    private boolean admin = false;
    private String message;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public int getUserId() {
        return userId;
    }

    public boolean isLoggedIn() {
        return loggedIn;
    }

    public boolean isAdmin() {
        return admin;
    }

    public String getMessage() {
        return message;
    }

    public String login() {
        UserDAO dao = new UserDAO();
        User user = dao.login(email, password);

        if (user != null) {
            this.userId = user.getUserId();
            this.name = user.getName();
            this.email = user.getEmail();
            this.loggedIn = true;
            this.admin = "admin@chococart.com".equalsIgnoreCase(user.getEmail());
            this.message = null;
            this.password = null;
            return "index?faces-redirect=true";
        } else {
            this.message = "Incorrect email or password.";
            this.loggedIn = false;
            this.admin = false;
            return null;
        }
    }

    public String logout() {
        email = null;
        password = null;
        name = null;
        userId = 0;
        loggedIn = false;
        admin = false;
        message = null;
        return "index?faces-redirect=true";
    }
}