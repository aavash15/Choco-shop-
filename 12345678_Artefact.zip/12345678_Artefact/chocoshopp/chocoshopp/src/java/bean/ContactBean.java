package bean;

import dao.ContactDAO;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.List;
import model.ContactMessage;

@Named("contactBean")
@RequestScoped
public class ContactBean implements Serializable {

    private String name;
    private String email;
    private String subject;
    private String message;
    private String statusMessage;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public String sendMessage() {
        if (name == null || name.trim().isEmpty()
                || email == null || email.trim().isEmpty()
                || subject == null || subject.trim().isEmpty()
                || message == null || message.trim().isEmpty()) {
            statusMessage = "Please fill in all fields.";
            return null;
        }

        ContactMessage contact = new ContactMessage();
        contact.setName(name);
        contact.setEmail(email);
        contact.setSubject(subject);
        contact.setMessage(message);

        ContactDAO dao = new ContactDAO();
        boolean success = dao.saveMessage(contact);

        if (success) {
            statusMessage = "Message successfully sent.";
            name = "";
            email = "";
            subject = "";
            message = "";
        } else {
            statusMessage = "Failed to send message.";
        }

        return null;
    }

    public List<ContactMessage> getAllMessages() {
        ContactDAO dao = new ContactDAO();
        return dao.getAllMessages();
    }
}