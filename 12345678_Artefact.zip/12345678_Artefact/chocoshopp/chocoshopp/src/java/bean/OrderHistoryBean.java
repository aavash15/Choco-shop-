package bean;

import dao.OrderDAO;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.ArrayList;
import java.util.List;
import model.Order;

@Named("orderHistoryBean")
@RequestScoped
public class OrderHistoryBean {

    @Inject
    private LoginBean loginBean;

    private List<Order> orders = new ArrayList<>();

    @PostConstruct
    public void init() {
        if (loginBean != null && loginBean.isLoggedIn()) {
            OrderDAO dao = new OrderDAO();
            orders = dao.getOrdersByUserId(loginBean.getUserId());
        }
    }

    public List<Order> getOrders() {
        return orders;
    }
}