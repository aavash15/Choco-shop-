package bean;

import dao.UserDAO;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import model.User;

@Named("registerBean")
@RequestScoped
public class RegisterBean implements Serializable {

    private String name;
    private String email;
    private String password;
    private String confirmPassword;
    private String message;

    public RegisterBean() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public String getMessage() {
        return message;
    }

    public String register() {
        if (name == null || name.trim().isEmpty()
                || email == null || email.trim().isEmpty()
                || password == null || password.trim().isEmpty()
                || confirmPassword == null || confirmPassword.trim().isEmpty()) {
            message = "Missing fields. Please fill in all fields.";
            return null;
        }

        UserDAO dao = new UserDAO();

        if (dao.emailExists(email)) {
            message = "Email already exists.";
            return null;
        }

        if (!password.equals(confirmPassword)) {
            message = "Passwords do not match.";
            return null;
        }

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);

        boolean success = dao.registerUser(user);

        if (success) {
            message = "Registration successful.";
            return "login?faces-redirect=true";
        } else {
            message = "Registration failed.";
            return null;
        }
    }
}