package bean;

import dao.OrderDAO;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import java.util.List;
import model.Order;

@Named("adminBean")
@RequestScoped
public class AdminBean {

    private List<Order> allOrders;

    @PostConstruct
    public void init() {
        OrderDAO dao = new OrderDAO();
        allOrders = dao.getAllOrders();
    }

    public List<Order> getAllOrders() {
        return allOrders;
    }

    public void setAllOrders(List<Order> allOrders) {
        this.allOrders = allOrders;
    }
}