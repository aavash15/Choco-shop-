package bean;

import dao.ProductDAO;
import model.Product;
import jakarta.inject.Named;
import jakarta.enterprise.context.RequestScoped;
import jakarta.annotation.PostConstruct;
import java.util.List;

@Named("productBean")
@RequestScoped
public class ProductBean {

    private List<Product> productList;

    @PostConstruct
    public void init() {
        System.out.println("ProductBean started");
        ProductDAO dao = new ProductDAO();
        productList = dao.getAllProducts();
        System.out.println("Bean products: " + productList.size());
    }

    public List<Product> getProductList() {
        return productList;
    }

    public int getStockByName(String productName) {
        ProductDAO dao = new ProductDAO();
        return dao.getStockByName(productName);
    }
}