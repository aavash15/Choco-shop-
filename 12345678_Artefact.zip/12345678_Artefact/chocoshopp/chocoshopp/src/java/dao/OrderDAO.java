package dao;

import util.DBConnection;
import model.Order;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {

    public boolean addOrder(int userId, double total) {
        boolean success = false;

        try {
            Connection conn = DBConnection.getConnection();
            String sql = "INSERT INTO ORDERS (USER_ID, TOTAL, ORDER_DATE) VALUES (?, ?, CURRENT_TIMESTAMP)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ps.setDouble(2, total);

            int rows = ps.executeUpdate();
            success = rows > 0;

            ps.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return success;
    }

    public List<Order> getOrdersByUserId(int userId) {
        List<Order> orders = new ArrayList<>();

        try {
            Connection conn = DBConnection.getConnection();
            String sql = "SELECT * FROM ORDERS WHERE USER_ID = ? ORDER BY ORDER_DATE DESC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Order order = new Order();
                order.setOrderId(rs.getInt("ORDER_ID"));
                order.setUserId(rs.getInt("USER_ID"));
                order.setTotal(rs.getDouble("TOTAL"));
                order.setOrderDate(rs.getTimestamp("ORDER_DATE"));
                orders.add(order);
            }

            rs.close();
            ps.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return orders;
    }

    public List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();

        try {
            Connection conn = DBConnection.getConnection();
            String sql = "SELECT * FROM ORDERS ORDER BY ORDER_DATE DESC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Order order = new Order();
                order.setOrderId(rs.getInt("ORDER_ID"));
                order.setUserId(rs.getInt("USER_ID"));
                order.setTotal(rs.getDouble("TOTAL"));
                order.setOrderDate(rs.getTimestamp("ORDER_DATE"));
                orders.add(order);
            }

            rs.close();
            ps.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return orders;
    }
}