package dao;

import util.DBConnection;
import model.Product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();

        try {
            Connection conn = DBConnection.getConnection();
            System.out.println("Connected to DB");

            String sql = "SELECT * FROM PRODUCTS";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Product p = new Product();
                p.setProductId(rs.getInt("PRODUCT_ID"));
                p.setName(rs.getString("NAME"));
                p.setDescription(rs.getString("DESCRIPTION"));
                p.setPrice(rs.getDouble("PRICE"));
                p.setStock(rs.getInt("STOCK"));
                products.add(p);
            }

            System.out.println("Products loaded: " + products.size());

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return products;
    }

    public int getStockByName(String productName) {
        int stock = 0;

        try {
            Connection conn = DBConnection.getConnection();

            String sql = "SELECT STOCK FROM PRODUCTS WHERE NAME = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, productName);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                stock = rs.getInt("STOCK");
            }

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return stock;
    }

    public void reduceStock(String productName, int quantityBought) {
        try {
            Connection conn = DBConnection.getConnection();

            String sql = "UPDATE PRODUCTS SET STOCK = STOCK - ? WHERE NAME = ? AND STOCK >= ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, quantityBought);
            ps.setString(2, productName);
            ps.setInt(3, quantityBought);

            ps.executeUpdate();

            ps.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}