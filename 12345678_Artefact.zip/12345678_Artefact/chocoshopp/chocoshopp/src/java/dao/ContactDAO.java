package dao;

import model.ContactMessage;
import util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ContactDAO {

    public boolean saveMessage(ContactMessage contact) {
        boolean success = false;

        try {
            Connection conn = DBConnection.getConnection();

            String sql = "INSERT INTO CONTACT_MESSAGES (NAME, EMAIL, SUBJECT, MESSAGE) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, contact.getName());
            ps.setString(2, contact.getEmail());
            ps.setString(3, contact.getSubject());
            ps.setString(4, contact.getMessage());

            int rows = ps.executeUpdate();
            success = rows > 0;

            ps.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return success;
    }

    public List<ContactMessage> getAllMessages() {
        List<ContactMessage> messages = new ArrayList<>();

        try {
            Connection conn = DBConnection.getConnection();

            String sql = "SELECT * FROM CONTACT_MESSAGES ORDER BY SENT_AT DESC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                ContactMessage msg = new ContactMessage();
                msg.setMessageId(rs.getInt("MESSAGE_ID"));
                msg.setName(rs.getString("NAME"));
                msg.setEmail(rs.getString("EMAIL"));
                msg.setSubject(rs.getString("SUBJECT"));
                msg.setMessage(rs.getString("MESSAGE"));
                msg.setSentAt(rs.getTimestamp("SENT_AT"));
                messages.add(msg);
            }

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return messages;
    }
}